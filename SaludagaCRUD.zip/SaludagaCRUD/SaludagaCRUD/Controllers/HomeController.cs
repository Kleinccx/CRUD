﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SaludagaCRUD.Controllers
{
    public class HomeController : Controller    
    {
        // GET: Home
        public ActionResult Index()
        {
            var list = new List<user>();
            using (var db = new dbsys32Entities1())
            {
                //Select * from user
                list = db.users.ToList();
            }


            return View(list);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(user u)
        {
            using (var db = new dbsys32Entities1())
            {
                var newUser = new user();
                newUser.username = u.username;
                newUser.password = u.password;

                db.users.Add(newUser);


                db.SaveChanges();
                TempData["msg"] = $"Added {newUser.username} successfully!";
            }
            return RedirectToAction("Index");

        }

    
        public ActionResult Update(int id)
        {
            var u = new user();
            using (var db = new dbsys32Entities1())
            {
                u = db.users.Find(id);
            }
            return View(u);
        }

        [HttpPost]
        public ActionResult Update(user u) 
        {
            using (var db = new dbsys32Entities1())
            {
                var newUser = db.users.Find(u.id);
                newUser.username = u.username;
                newUser.password = u.password;

                db.SaveChanges();

                TempData["msg"] = $"Updated {newUser.username} successfully!";
            }
            return RedirectToAction("Index");
        }
        public ActionResult Delete(int id)
        {
            var u = new user();
            using (var db = new dbsys32Entities1())
            {
                u = db.users.Find(id);
                db.users.Remove(u);
                db.SaveChanges();

                TempData["msg"] = $"Deleted {u.username} successfully!";
            }
            return RedirectToAction("Index");
        }

    }
}   